import sys

if __name__ == "__main__":
    from ctypes.wrap.xml2py import main
    sys.exit(main())
