import sys
from ctypes_codegen.xml2py_main import main

if __name__ == "__main__":
    sys.exit(main())
