import sys
from ctypes_codegen.h2xml_main import main

if __name__ == "__main__":
    sys.exit(main())
