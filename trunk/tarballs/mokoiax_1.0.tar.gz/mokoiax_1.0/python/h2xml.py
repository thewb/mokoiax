
if __name__ == "__main__":
    from ctypes.wrap.h2xml import main
    main()
