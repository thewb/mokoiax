#define RBUFSIZE 256
#define MAXARGS 10
#define MAXARG 256
#define MAX_SESSIONS 4

extern void parse_cmd(FILE *, int, char **);
