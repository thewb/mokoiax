/*
 * Copyrights:
 * Copyright (C) 2006 Gatherworks.com
 *
 * Contributors:
 * Frik Strecker <frik@gatherworks.com>
 * Bill Welch <bill@gatherworks.com>
 *
 *
 * This program is free software, distributed under the terms of
 * the GNU Lesser (Library) General Public License
 */

//#define INITGUID
//#include <initguid.h>
#include <windows.h>

BOOL APIENTRY DllMain(
	HANDLE			hModule, 
    DWORD			ul_reason_for_call, 
    LPVOID			lpReserved)
{
    return TRUE;
}

/* #EOF# */

