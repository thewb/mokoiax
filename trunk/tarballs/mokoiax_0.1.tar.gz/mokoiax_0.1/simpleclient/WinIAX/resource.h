//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDD_MAIN_DLG                    101
#define IDD_DLG_REGISTER                102
#define IDR_MENU1                       103
#define IDR_RING                        104
#define IDI_ICON2                       108
#define IDI_ICON1                       108
#define IDD_DLG_SOUND                   109
#define IDD_DLG_PREFERENCES             112
#define IDC_BN_DIAL                     1000
#define IDC_E_IAX_URI                   1001
#define IDC_BN_HANGUP                   1002
#define IDC_ST_STATUS                   1004
#define IDC_BN_1                        1012
#define IDC_BN_2                        1013
#define IDC_BN_3                        1014
#define IDC_BN_4                        1015
#define IDC_BN_5                        1016
#define IDC_BN_6                        1017
#define IDC_BN_7                        1018
#define IDC_BN_8                        1019
#define IDC_BN_9                        1020
#define IDC_BN_ASTERISK                 1021
#define IDC_BN_0                        1022
#define IDC_BN_HASH                     1023
#define IDC_PROG_OUTPUT                 1024
#define IDC_PROG_INPUT                  1025
#define IDC_E_GATEWAY                   1026
#define IDC_E_USER                      1027
#define IDC_E_PASS                      1028
#define IDC_ST_GATEWAY                  1029
#define IDC_ST_USER_NAME                1030
#define IDC_ST_PASSWORD                 1031
#define IDC_RD_LINE_1                   1032
#define IDC_RD_LINE_2                   1033
#define IDC_RD_LINE_3                   1034
#define IDC_ST_STATE                    1035
#define IDC_CMB_PLAYBACK                1036
#define IDC_CMB_RECORDING               1037
#define IDC_CMB_RINGTONE                1038
#define IDC_CHK_PTT                     1040
#define IDC_CHK_SILENCE                 1042
#define IDC_BN_BG                       1044
#define IDC_BN_TEXT                     1045
#define IDC_ST_TXTCLR                   1046
#define IDC_ST_BGCLR                    1047
#define ID_FILE_REGISTER                40001
#define ID_FILE_EXIT                    40002
#define ID_TOOLS_SOUNDSETTINGS          40003
#define ID_TOOLS_PREFERENCES            40004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        113
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1048
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
